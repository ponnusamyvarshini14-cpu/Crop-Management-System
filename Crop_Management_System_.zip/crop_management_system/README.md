# CropMate – Crop Management System

A Flask + SQLite agriculture management system with a public landing page, registration/login, a premium CropMate dashboard, 11 management modules, clickable detail pages, add/delete actions, and password-protected deletion.

## Dashboard
The main dashboard is redesigned to match the approved CropMate mockup:
- Total Farmers
- Active Crops
- Total Fields
- Total Revenue
- Farmers by Crop
- Farm Overview
- Quick Actions
- Farm banner
- Recent Activity

The old **Production by Crop** chart has been removed.

## Demo login
- Email: `admin@cropmate.com`
- Password: `admin123`

## Run
```bash
cd crop_management_system
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

## Included demo data
Exactly **100 records** are included in each main data table:
- 100 Farmers
- 100 Fields
- 100 Crops
- 100 Production records
- 100 Fertilizer records
- 100 Irrigation records
- 100 Harvest records
- 100 Sales records
- 100 Activity records

The relational demo data is generated for the project. Kaggle references are included as real-data sources for future integration; the demo dataset should not be represented as a direct copy of a Kaggle dataset.

## Kaggle references
- https://www.kaggle.com/competitions/agriculture-precission-study-cases/data
- https://www.kaggle.com/patelris/crop-yield-prediction-dataset
- https://www.kaggle.com/code/vuyurudeepthi/crop-yield-of-a-farm/input
- https://www.kaggle.com/dsv/9239304
