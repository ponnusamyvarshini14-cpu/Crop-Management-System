from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import sqlite3, os, hashlib
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = BASE / "data" / "cropmate.db"
app = Flask(__name__)
app.secret_key = "cropmate-demo-secret-change-me"


def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con


def hashpw(p):
    return hashlib.sha256(p.encode()).hexdigest()


MODULES = {
    "farmers": ("Farmers", "👨‍🌾"), "fields": ("Fields", "🏞️"), "crops": ("Crops", "🌱"),
    "production": ("Production", "📊"), "fertilizer": ("Fertilizer", "🧪"), "irrigation": ("Irrigation", "💧"),
    "harvest": ("Harvest", "🌾"), "sales": ("Sales", "💰"), "analytics": ("Analytics", "📈"),
    "reports": ("Reports", "📑"), "activity": ("Activity Log", "📋")
}

# Fields used by the Add forms. IDs are auto-created, except foreign keys which are selected from data.
FORM_FIELDS = {
    "farmers": [("name", "Farmer Name", "text"), ("location", "Location", "text"), ("phone", "Phone", "text"), ("joined", "Joined Date", "date"), ("farm_area", "Farm Area (acres)", "number")],
    "fields": [("farmer_id", "Farmer", "farmer"), ("name", "Field Name", "text"), ("area", "Area (acres)", "number"), ("location", "Location", "text"), ("soil", "Soil Type", "text"), ("crop", "Current Crop", "text"), ("irrigation", "Irrigation Method", "text")],
    "crops": [("field_id", "Field", "field"), ("farmer_id", "Farmer", "farmer"), ("name", "Crop Name", "text"), ("stage", "Growth Stage", "text"), ("sowing", "Sowing Date", "date"), ("expected", "Expected Harvest", "date"), ("yield_tpha", "Expected Yield (t/ha)", "number")],
    "production": [("field_id", "Field", "field"), ("farmer_id", "Farmer", "farmer"), ("crop", "Crop", "text"), ("season", "Season", "text"), ("quantity", "Quantity (t)", "number"), ("year", "Year", "number")],
    "fertilizer": [("field_id", "Field", "field"), ("farmer_id", "Farmer", "farmer"), ("crop", "Crop", "text"), ("name", "Fertilizer Name", "text"), ("quantity", "Quantity (kg)", "number"), ("date", "Application Date", "date"), ("cost", "Cost (₹)", "number")],
    "irrigation": [("field_id", "Field", "field"), ("farmer_id", "Farmer", "farmer"), ("crop", "Crop", "text"), ("method", "Method", "text"), ("date", "Irrigation Date", "date"), ("water", "Water (m³)", "number"), ("duration", "Duration (min)", "number")],
    "harvest": [("field_id", "Field", "field"), ("farmer_id", "Farmer", "farmer"), ("crop", "Crop", "text"), ("date", "Harvest Date", "date"), ("quantity", "Quantity (t)", "number"), ("grade", "Grade", "text"), ("storage", "Storage", "text")],
    "sales": [("field_id", "Field", "field"), ("farmer_id", "Farmer", "farmer"), ("crop", "Crop", "text"), ("buyer", "Buyer", "text"), ("date", "Sale Date", "date"), ("quantity", "Quantity", "number"), ("price", "Price / ton (₹)", "number"), ("revenue", "Revenue (₹)", "number")],
    "activity": [("farmer_id", "Farmer", "farmer"), ("field_id", "Field", "field"), ("crop", "Crop", "text"), ("type", "Activity Type", "text"), ("description", "Description", "text"), ("date", "Date", "date")]
}


def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password TEXT, phone TEXT, location TEXT, farm_name TEXT, farm_area REAL);
    CREATE TABLE IF NOT EXISTS farmers(id INTEGER PRIMARY KEY, name TEXT, location TEXT, phone TEXT, joined TEXT, farm_area REAL);
    CREATE TABLE IF NOT EXISTS fields(id INTEGER PRIMARY KEY, farmer_id INTEGER, name TEXT, area REAL, location TEXT, soil TEXT, crop TEXT, irrigation TEXT);
    CREATE TABLE IF NOT EXISTS crops(id INTEGER PRIMARY KEY, field_id INTEGER, farmer_id INTEGER, name TEXT, stage TEXT, sowing TEXT, expected TEXT, yield_tpha REAL);
    CREATE TABLE IF NOT EXISTS production(id INTEGER PRIMARY KEY, field_id INTEGER, farmer_id INTEGER, crop TEXT, season TEXT, quantity REAL, year INTEGER);
    CREATE TABLE IF NOT EXISTS fertilizer(id INTEGER PRIMARY KEY, field_id INTEGER, farmer_id INTEGER, crop TEXT, name TEXT, quantity REAL, date TEXT, cost REAL);
    CREATE TABLE IF NOT EXISTS irrigation(id INTEGER PRIMARY KEY, field_id INTEGER, farmer_id INTEGER, crop TEXT, method TEXT, date TEXT, water REAL, duration INTEGER);
    CREATE TABLE IF NOT EXISTS harvest(id INTEGER PRIMARY KEY, field_id INTEGER, farmer_id INTEGER, crop TEXT, date TEXT, quantity REAL, grade TEXT, storage TEXT);
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, field_id INTEGER, farmer_id INTEGER, crop TEXT, buyer TEXT, date TEXT, quantity REAL, price REAL, revenue REAL);
    CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY, farmer_id INTEGER, field_id INTEGER, crop TEXT, type TEXT, description TEXT, date TEXT);
    """)
    if not con.execute("SELECT 1 FROM users WHERE email='admin@cropmate.com'").fetchone():
        con.execute("INSERT INTO users(name,email,password,phone,location,farm_name,farm_area) VALUES(?,?,?,?,?,?,?)",
                    ("Admin Farmer", "admin@cropmate.com", hashpw("admin123"), "+91 9000000000", "Chennai", "CropMate Demo Farm", 25))
    if not con.execute("SELECT 1 FROM farmers LIMIT 1").fetchone():
        import csv
        for table in ["farmers", "fields", "crops", "production", "fertilizer", "irrigation", "harvest", "sales", "activity"]:
            with open(BASE / "data" / f"{table}.csv", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            cols = list(rows[0].keys()); qs = ",".join(["?"] * len(cols))
            con.executemany(f"INSERT INTO {table} ({','.join(cols)}) VALUES ({qs})", [[r[c] for c in cols] for r in rows])
    con.commit(); con.close()


@app.context_processor
def common():
    return {"logged_in": "user_id" in session, "user_name": session.get("user_name", "Farmer"), "modules": MODULES}


@app.route("/")
def landing(): return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        if f["password"] != f["confirm_password"]:
            flash("Passwords do not match."); return render_template("register.html")
        con = db()
        try:
            con.execute("INSERT INTO users(name,email,password,phone,location,farm_name,farm_area) VALUES(?,?,?,?,?,?,?)",
                        (f["name"], f["email"], hashpw(f["password"]), f["phone"], f["location"], f["farm_name"], f["farm_area"]))
            con.commit()
        except sqlite3.IntegrityError:
            flash("Email already registered."); con.close(); return render_template("register.html")
        con.close(); flash("Account created successfully. Please login."); return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]; pw = hashpw(request.form["password"])
        con = db(); u = con.execute("SELECT * FROM users WHERE email=? AND password=?", (email, pw)).fetchone(); con.close()
        if u:
            session["user_id"] = u["id"]; session["user_name"] = u["name"]; return redirect(url_for("dashboard"))
        flash("Invalid email or password.")
    return render_template("login.html")


@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("landing"))


def require_login():
    return "user_id" in session


@app.route("/dashboard")
def dashboard():
    if not require_login(): return redirect(url_for("login"))
    con = db()
    stats = {
        "farmers": con.execute("SELECT COUNT(*) c FROM farmers").fetchone()["c"],
        "active_crops": con.execute("SELECT COUNT(DISTINCT name) c FROM crops").fetchone()["c"],
        "fields": con.execute("SELECT COUNT(*) c FROM fields").fetchone()["c"],
        "revenue": round(con.execute("SELECT COALESCE(SUM(revenue),0) s FROM sales").fetchone()["s"], 0),
        "farm_area": round(con.execute("SELECT COALESCE(SUM(area),0) s FROM fields").fetchone()["s"], 0),
        "harvest_ready": 38,
        "irrigation_due": 24,
        "low_stock": 12
    }
    farmers_by_crop = con.execute("SELECT name crop, COUNT(DISTINCT farmer_id) farmers FROM crops GROUP BY name ORDER BY farmers DESC").fetchall()
    recent = con.execute("SELECT a.*, f.name farmer_name FROM activity a JOIN farmers f ON f.id=a.farmer_id ORDER BY a.id DESC LIMIT 6").fetchall()
    con.close()
    return render_template("dashboard.html", stats=stats, farmers_by_crop=farmers_by_crop, recent=recent, modules=MODULES)


def fetch_module_data(name):
    con = db(); data = []
    if name == "farmers": data = con.execute("SELECT * FROM farmers ORDER BY id DESC").fetchall()
    elif name == "fields": data = con.execute("SELECT fields.*, farmers.name farmer_name FROM fields JOIN farmers ON farmers.id=fields.farmer_id ORDER BY fields.id DESC").fetchall()
    elif name == "crops": data = con.execute("SELECT crops.*, fields.name field_name, farmers.name farmer_name FROM crops JOIN fields ON fields.id=crops.field_id JOIN farmers ON farmers.id=crops.farmer_id ORDER BY crops.id DESC").fetchall()
    elif name in ["production", "fertilizer", "irrigation", "harvest", "sales", "activity"]: data = con.execute(f"SELECT * FROM {name} ORDER BY id DESC").fetchall()
    elif name == "analytics": data = con.execute("SELECT crop, ROUND(SUM(quantity),2) total FROM production GROUP BY crop ORDER BY total DESC").fetchall()
    elif name == "reports": data = con.execute("""SELECT farmers.location location, COUNT(DISTINCT farmers.id) farmers, COUNT(DISTINCT fields.id) fields,
        ROUND(COALESCE(SUM(DISTINCT production.quantity),0),2) production, ROUND(COALESCE(SUM(DISTINCT sales.revenue),0),0) revenue
        FROM farmers LEFT JOIN fields ON fields.farmer_id=farmers.id LEFT JOIN production ON production.field_id=fields.id LEFT JOIN sales ON sales.field_id=fields.id
        GROUP BY farmers.location ORDER BY revenue DESC""").fetchall()
    con.close(); return data


@app.route("/module/<name>")
def module(name):
    if not require_login(): return redirect(url_for("login"))
    if name not in MODULES: return redirect(url_for("dashboard"))
    con = db()
    options = {"farmers": con.execute("SELECT id,name FROM farmers ORDER BY name").fetchall(),
               "fields": con.execute("SELECT id,name,farmer_id FROM fields ORDER BY name").fetchall()}
    con.close()
    return render_template("module.html", name=name, title=MODULES[name][0], icon=MODULES[name][1], data=fetch_module_data(name), form_fields=FORM_FIELDS.get(name), options=options)


@app.route("/add/<name>", methods=["POST"])
def add_record(name):
    if not require_login() or name not in FORM_FIELDS: return redirect(url_for("dashboard"))
    f = request.form
    fields = [x[0] for x in FORM_FIELDS[name]]
    vals = [f.get(x, "") for x in fields]
    # Numeric blanks become 0 so demo forms remain forgiving.
    numeric = {"number" for _,_,t in FORM_FIELDS[name]}
    vals = [float(v) if t == "number" and v != "" else (0 if t == "number" else v) for v,(k,l,t) in zip(vals, FORM_FIELDS[name])]
    if name == "sales" and (not f.get("revenue")):
        vals[fields.index("revenue")] = float(f.get("quantity") or 0) * float(f.get("price") or 0)
    con = db(); cols = ",".join(fields); qs = ",".join(["?"] * len(fields))
    con.execute(f"INSERT INTO {name} ({cols}) VALUES ({qs})", vals)
    con.commit(); con.close(); flash(f"{MODULES[name][0][:-1] if name.endswith('s') else MODULES[name][0]} added successfully.")
    return redirect(url_for("module", name=name))


@app.route("/delete/<name>/<int:rid>", methods=["POST"])
def delete_record(name, rid):
    if not require_login() or name not in FORM_FIELDS: return redirect(url_for("dashboard"))
    password = request.form.get("password", "")
    con = db(); u = con.execute("SELECT password FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if not u or hashpw(password) != u["password"]:
        con.close(); flash("Incorrect password. Record was not deleted."); return redirect(url_for("module", name=name))
    con.execute(f"DELETE FROM {name} WHERE id=?", (rid,)); con.commit(); con.close()
    flash("Record deleted successfully."); return redirect(url_for("module", name=name))


@app.route("/detail/<name>/<int:rid>")
def detail(name, rid):
    if not require_login(): return redirect(url_for("login"))
    if name not in MODULES: return redirect(url_for("dashboard"))
    con = db(); row = None; related = []
    if name == "farmers":
        row = con.execute("SELECT * FROM farmers WHERE id=?", (rid,)).fetchone()
        related = [
            ("Fields", con.execute("SELECT * FROM fields WHERE farmer_id=?", (rid,)).fetchall()),
            ("Crops", con.execute("SELECT * FROM crops WHERE farmer_id=?", (rid,)).fetchall()),
            ("Production", con.execute("SELECT * FROM production WHERE farmer_id=? ORDER BY id DESC LIMIT 10", (rid,)).fetchall()),
            ("Sales", con.execute("SELECT * FROM sales WHERE farmer_id=? ORDER BY id DESC LIMIT 10", (rid,)).fetchall())]
    elif name == "fields":
        row = con.execute("SELECT fields.*, farmers.name farmer_name FROM fields JOIN farmers ON farmers.id=fields.farmer_id WHERE fields.id=?", (rid,)).fetchone()
        related = [("Crops", con.execute("SELECT * FROM crops WHERE field_id=?", (rid,)).fetchall()), ("Production", con.execute("SELECT * FROM production WHERE field_id=?", (rid,)).fetchall()), ("Irrigation", con.execute("SELECT * FROM irrigation WHERE field_id=?", (rid,)).fetchall()), ("Harvest", con.execute("SELECT * FROM harvest WHERE field_id=?", (rid,)).fetchall())]
    elif name == "crops":
        row = con.execute("SELECT crops.*, fields.name field_name, farmers.name farmer_name FROM crops JOIN fields ON fields.id=crops.field_id JOIN farmers ON farmers.id=crops.farmer_id WHERE crops.id=?", (rid,)).fetchone()
        related = [("Production", con.execute("SELECT * FROM production WHERE farmer_id=? AND crop=?", (row["farmer_id"], row["name"])).fetchall()), ("Fertilizer", con.execute("SELECT * FROM fertilizer WHERE farmer_id=? AND crop=?", (row["farmer_id"], row["name"])).fetchall()), ("Harvest", con.execute("SELECT * FROM harvest WHERE farmer_id=? AND crop=?", (row["farmer_id"], row["name"])).fetchall()), ("Sales", con.execute("SELECT * FROM sales WHERE farmer_id=? AND crop=?", (row["farmer_id"], row["name"])).fetchall())]
    elif name in ["production", "fertilizer", "irrigation", "harvest", "sales", "activity"]:
        row = con.execute(f"SELECT * FROM {name} WHERE id=?", (rid,)).fetchone()
        if row and "farmer_id" in row.keys(): related = [("Farmer", con.execute("SELECT * FROM farmers WHERE id=?", (row["farmer_id"],)).fetchall())]
    elif name == "analytics":
        rows = con.execute("SELECT crop, ROUND(SUM(quantity),2) total FROM production GROUP BY crop ORDER BY total DESC").fetchall(); row = next((r for r in rows if r["crop"] == str(rid)), rows[0] if rows else None)
    elif name == "reports":
        rows = con.execute("SELECT farmers.location location, COUNT(DISTINCT farmers.id) farmers, COUNT(DISTINCT fields.id) fields, ROUND(COALESCE(SUM(production.quantity),0),2) production, ROUND(COALESCE(SUM(sales.revenue),0),0) revenue FROM farmers LEFT JOIN fields ON fields.farmer_id=farmers.id LEFT JOIN production ON production.field_id=fields.id LEFT JOIN sales ON sales.field_id=fields.id GROUP BY farmers.location ORDER BY revenue DESC").fetchall()
        row = rows[rid-1] if 0 < rid <= len(rows) else None
    con.close()
    if not row: return redirect(url_for("module", name=name))
    return render_template("detail.html", name=name, title=MODULES[name][0], icon=MODULES[name][1], row=row, related=related)


@app.route("/api/summary")
def summary():
    con = db(); rows = con.execute("SELECT crop, ROUND(SUM(quantity),2) total FROM production GROUP BY crop ORDER BY total DESC").fetchall(); con.close(); return jsonify([dict(r) for r in rows])


init_db()
if __name__ == "__main__": app.run(debug=True)
